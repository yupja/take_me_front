import React from "react";

const GoalADD = ()=>{
  return (
    <div> 오호! </div>
  )
}

export default GoalADD;
